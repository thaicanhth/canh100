package Chuong3;
//Cấu trúc điều khiển lập do-while
public class Bai16 {
    public static void main(String[] args) {
        /*
        do{
        làm gì đó;
        }while(điều kiện lập);
         */
        int i = 3;
        do {
            System.out.println("Hello");
                    i--;
        }while (i != 0);
    }
}
