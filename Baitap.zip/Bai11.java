package Chuong3;
//Giới thiệu lập trình

public class Bai11 {
    public static void main(String[] args) {
        int x = 90;
        double xIr = Math.toRadians(x);
        double res = Math. sin(xIr);//radian
        System.out.println("sin(90) = " + res);
        System.out.println("PI = " + Math.PI);
    }
}
