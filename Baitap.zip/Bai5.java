package Chuong3;
//Comment trong ngôn ngữ lập trình java
//blabla

public class Bai5 {
    public static void main(String[] args) {
        int a = 100; // gán a = 100
        int b = 255; // gán b = 255
        int sum = a + b;

        // System.out.println(sum);
    }
    /*
     comment
     tren nhieu
     dong
     deu ok
     ko thanh van de
     hahaha...
     */

    /**
     * day la chuong trinh minh hoa su dung comment
     * hahaha...
     */
}
