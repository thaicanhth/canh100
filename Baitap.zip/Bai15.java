package Chuong3;
// Cấu trúc điều khiển lập while
public class Bai15 {
    public static void main(String[] args) {
        /*
            while(điều kiện lập){
               làm cái gì đó;
            }
         */
        int i = 100;
//       while (true) {// vong lap vo ha
//           System.out.println(i)
//      }
        for (;;){// vong lap vo han
            System.out.println(i);
        }
        // thuc hien tiep...
    }
}
