package Chuong3;
/*
- toán tử logic: && / !
- toán tử ba ngôi epression ? x : y
- thứ tự ưu tiên các toán tử
- giới thiệu enum.
 */
public class Bai8 {
    /*
    - toán tử tăng/giảm: x++ --x ++x x--
    - toán tử so sánh: > < >= <= == !=
     */
    public static void main(String[] args) {
        int a = 5;
        int b = 9;
        System.out.println("a == b:" + (a == b));
        System.out.println("a >= b:" +(a >= b));
        System.out.println("a <= b:" +(a <= b));
    }
}
