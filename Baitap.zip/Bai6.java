package Chuong3;
//các kí tự có chức năng đặc biệt
/*
 \n: cho phep xuong dong
 \b: xoa bo mo ki tu tu cuoi day
 */

public class Bai6 {
    public static void main(String[] args) {
        System.out.println("Java\nTuterial\n07\b\b");
    }
}
