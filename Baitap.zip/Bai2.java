package Chuong3;
//Biến trong ngôn ngữ lập trình java
public class Bai2 {
    public static void main(String[] args) {
        //your codes go here
        int firstNumber = 100;
        int secondNumber = 255;
        int sun = firstNumber + secondNumber;
        long myValue;
        boolean isTrue;
        char character = '1';
        double laiSuat;
        System.out.println("SUN OF TWO NUMBER:" + (firstNumber+secondNumber)+","+character);
    }
}
