package Chuong3;
// Hằng số trong ngôn ngữ lập trình java

public class Bai3 {
    public static final double PI = 3.141592;// so PI
    public static final float G = 9.789F;

    public static void main(String[] args) {
        System.out.println(G);
        showGValue();
        showpialue();
    }

    public static void showGValue() {
        System.out.println(G);

    }

    public static void showpialue() {
        System.out.println(PI);
    }
}
