package Chuong3;
//Khai bao cac thu vien
import  java.util.Scanner;

public class Baitap3_2 {
    //Khai bao doi tuong imput cua lop Scanner nhan du lieu vao
    private static Scanner input;
    //Chuong trinh chinh
    public static void main(String[] args) {
        //Khai bao doi tuong input
        input = new Scanner(System.in);
        //Nhap gia tri cho bien a, b, c kieu so thuc tu ban phim
        System.out.println("Nhap a: ");
        float a = input.nextFloat();
        System.out.println("Nhap b: ");
        float b = input.nextFloat();
        System.out.println("Nhap c: ");
        float c = input.nextFloat();
        //Tinh gia tri delta
        float delta=b*b-4*a*c;
        //Xet cac truong hop delta cho ra nghiem
        if (delta<0)
            System.out.println("Phương trình vô nghiệm.");
        else if (delta==0)
            System.out.println("Phương trình có nghiệm kép: "+(-b/(2*a)));
        else
            System.out.println("Phương trình có hai nghiệm:");
            System.out.println("X1 = "+(-b+Math.sqrt(delta))/(2*a));
            System.out.println("X2 = "+(-b-Math.sqrt(delta))/(2*a));
    }
}
