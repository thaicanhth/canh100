package Chuong3;
import java.util.Scanner;
public class Baitap3_8c {
        public static void main(String[] args) {
            int n;
            Scanner sc;
            do {
                System.out.print("Input n = ");
                sc = new Scanner(System.in);
                n = sc.nextInt();
            }while(n <= 0);


            System.out.println("Aliquot of " + n + ":");
            for(int i = 1; i <= n; i++) {
                if(n%i == 0) {
                    System.out.println(i);
                }
            }

            sc.close();
        }
    }

