package Chuong3;
import java.util.Scanner;

public class Baitap3_9 {
    public static int n;
    //--------ham tinh tong----------
    public static double tinhtong(int n) {
        double tml=1;
        if (n>1) {
            for (int i = 3; i <= n; i++) {
                tml *= i;
            }
        }
        return tml;
    }
    public static  void main(String[] args) {
        float tong = 0.0f;
        Scanner reader = new Scanner(System.in);
        System.out.print("Nhập số tự nhiên N = ");
        n = reader.nextInt();
        for (int i = 1; i <= n; i++) {
            tong+= i/tinhtong(i);
        }
        System.out.println("tong day so la: " + tong);
    }
}


