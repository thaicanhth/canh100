package Chuong3;
import java.util.Scanner;
public class Baitap3_11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a;
        a = scanner.nextInt();
        System.out.println("gia tri cua a: "+a);
        System.out.print("Nhập vào một số bất kì : ");
        int n = scanner.nextInt();
        if (isPrime(n)) {
            System.out.println(n + " Là số chính phương");
        } else {
            System.out.println(n + " Không phải là số chính phương");
        }
    }

    public static boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 4; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
