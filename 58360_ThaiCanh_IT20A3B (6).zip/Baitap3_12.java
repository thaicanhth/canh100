package Chuong3;
import java.util.Scanner;
public class Baitap3_12 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a;
        float b;
        a = scanner.nextInt();
        b = scanner.nextFloat();
        System.out.println("gia tri cua a: "+a);
        System.out.println("gia tri cua b: "+b);
        System.out.print("Nhập vào một số bất kì : ");
        int n = scanner.nextInt();
        if (isPrime(n)) {
            System.out.println(n + " Là số chính phương");
        } else {
            System.out.println(n + " Không phải là số chính phương");
        }
    }

    public static boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
