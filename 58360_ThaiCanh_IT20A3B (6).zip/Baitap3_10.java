package Chuong3;
import java.util.Scanner;
public class Baitap3_10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a;
        float b;
        a = scanner.nextInt();
        System.out.println("gia tri cua a: "+a);
        System.out.print("Nhập vào một số bất kì : ");
        int n = scanner.nextInt();
        if (isPrime(n)) {
            System.out.println(n + " Là số nguyên tố");
        } else {
            System.out.println(n + " Không phải là số nguyên tố");
        }
    }

    public static boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}



