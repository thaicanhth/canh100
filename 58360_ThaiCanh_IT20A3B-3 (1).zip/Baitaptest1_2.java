package Test01;
import java.util.Scanner;
public class Baitaptest1_2 {
    public static void main(String[] args) {
        int n;
        int dem = 0;
        Scanner scanner = new Scanner(System.in);
        {
            System.out.println("Nhập các phần tử của mảng: ");
            n =scanner.nextInt();
        }
        int A[] = new int[n];
        for (int i = 0; i < n; i++) {
            if (A[i] % 3 == 0 && A[i] % 4 != 0) {
                dem++;
            }
        }
        System.out.println("So gia tri chia het cho 3 ma khong chia het cho 4 la: " + dem);
    }
}
