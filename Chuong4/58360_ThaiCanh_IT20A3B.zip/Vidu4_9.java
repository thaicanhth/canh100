package Chuong4;
import java.util.Scanner;
public class Vidu4_9 {
    public static void main(String[] args) {
        String[] cars = { "HONda", "BMW", "Ford", "Mazda", };
        System.out.println("Độ sài của mảng cars là: " + cars.length);
    }
}
