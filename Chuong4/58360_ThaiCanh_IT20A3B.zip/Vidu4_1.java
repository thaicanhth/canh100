package Chuong4;

public class Vidu4_1 {
    public static void main(String[] args) {
        //Khai bao khoi tao gia tri ban đầu cho mảng
        char[] KyTu = new char[]{'a', 'b', 'c', 'd', 'e'};
        //Hiện thị ký tự tại vị trí thứ 2 trong mảng
        System.out.println("Ký tự tại vị trí thứ 2 trong mảng là " + KyTu[2]);
    }
}
