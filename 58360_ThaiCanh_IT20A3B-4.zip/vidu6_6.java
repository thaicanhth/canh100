package Chuong6;

public class vidu6_6 {
    public static void main(String[] args) {
        // khai báo một chuỗi có nội dung là "Welcome to java!"
        String chuoi = new String("Welcome to java!");
        System.out.println(chuoi);
    }
}
