package Chuong6;

import java.util.Scanner;

public class Baitap6_3 {
    //Khai bao doi tuong input cua lop Scanner nhan du lieu nhap vao
    private static Scanner input;
    public static void main(String[] args){
        // Khoi tao doi tuong input
        input = new Scanner(System.in);
        //Nhap gia tri cho bien m
        System.out.println("Nhập m: ");
        int m = input.nextInt();
        //Khai bao bien tong
        int tong=0;
        //Thuc hien vong lap de tinh tong cac so chan
        for(int i=0;i<=m;i++)
        {
            if(i%2==0)
                tong= +i;
        }
        System.out.println("Tổng các số chẵn rừ 0 đến m là: "+tong);
    }
}



