package Chuong6;

public class Baitap6_4 {
    public static void main(String[] args) {
        System.out.println("Giá trị nhị phân của 124 là: ");
        System.out.println(Integer.toBinaryString(155));
        System.out.println("\nGiá trị nhị phân của 45 là: ");
        System.out.println(Integer.toBinaryString(47));
        System.out.println("\ngiá trị nhị phân của 999 là: ");
        System.out.println(Integer.toBinaryString(999));
        System.out.println("----------------------------");
    }
}


