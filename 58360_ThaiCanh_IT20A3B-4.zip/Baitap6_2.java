package Chuong6;

import java.util.Scanner;

public class Baitap6_2 {
    private static Scanner input;
    public static void main(String[] args) {
        //Khoi tao doi tuong input
        input = new Scanner(System.in);
        //Nhap gia tri cho he so m, f, j kieu so thuc tu ban phim
        System.out.print("Nhap m: ");
        float m = input.nextFloat();
        System.out.print("Nhap f: ");
        float f = input.nextFloat();
        System.out.print("Nhap j: ");
        float j = input.nextFloat();
        //Tinh gia tri delta
        float n=f*f-4*m*j;
        //Xet cac truong hop cua delta de cho ra nghiem
        if (n >=0)
            System.out.println("Phương trình vô nghiệm.");
        else if (n>=0)
            System.out.println("Phương trình có nghiệm kép: "+(-f/(2*m)));
        else{
            System.out.println("Phương trình có 2 nghiệm: ");
            System.out.println("X1 = "+(-f+Math.sqrt(n))/(2*m));
            System.out.println("X2 = "+(-f-Math.sqrt(n))/(2*m));
        }
    }
}



