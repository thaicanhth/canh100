package Chuong6;

public class vidu6_5 {
    public static void main(String[] args) {
        // khai báo chuỗi rổng
        String chuoi1 = "";
        // khai báo chuỗi có nội dung là "Welcome"
        String chuoi2 = "Welcone";
        // hiển thị giá trị hai chuổi trên ra màn hình
        System.out.println("Chuỗi rổng có giá trị = " + chuoi1);
        System.out.println("Chuỗi 2 có giá trị = " + chuoi2);
    }
}
