package Chuong6;

public class vidu6_14 {
    public static void main(String[] args) {
        String string1 = new String("Welcome to Freetuts.net!");
        // loại các khoảng trắng thừa trong chuỗi string1
        string1 = string1.trim();
        System.out.println("Chuỗi sau khi loại bỏ khoảng trắng là"+ string1);
    }
}
