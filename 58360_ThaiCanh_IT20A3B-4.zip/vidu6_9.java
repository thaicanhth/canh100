package Chuong6;

public class vidu6_9 {
    public static void main(String[] args) {
        String chuoi = "Happy new year!";
        /*
        * trả về kí tự có chỉ số la 4 trong chuỗi
        * kí tự 'H' có chỉ số là 0, nên kí tự có chỉ số 4 là kí tự 'y'
         */
        char character=chuoi.charAt(4);
        System.out.println(character);
    }
}
